<?php
$con=mysqli_connect('localhost','testuser','testuser','bidwiz');
if(!$con){
    die("connection successfull");
}
?>